----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--
-- em_pluginsettings - em_map plugin
--
--
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------

print("[ Loading em_pluginsettings ]");

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------

em_pluginsettings = em_pluginsettings or {};
em_pluginsettings.requireGPS = em_pluginsettings.requireGPS or false;
em_pluginsettings.radarMode = em_pluginsettings.radarMode or false;
em_pluginsettings.psychicMode = em_pluginsettings.psychicMode or false;

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------

-- Plugin Settings

-- em_pluginsettings.requireGPS - require GPS to activate minimap.
-- em_pluginsettings.radarMode - disable sight checks (all loaded objects are visible).
-- em_pluginsettings.psychicMode - enable infinite range player locations on map.
-- em_pluginsettings.psychicModeFaction - enable infinite range player locations on map for faction groups.
-- em_pluginsettings.psychicModeCohabitants - enable infinite range player locations on map for safehouse groups.

-- em_pluginsettings.lua must have a unique name or path for compatibility.
-- if multiple em_pluginsettings.lua are found in the same path in different mods, PZ will only enable one.

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------