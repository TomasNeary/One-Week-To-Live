----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
--
-- em_communitymap - em_map plugin
--
--
----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------

print("[ Loading EM_COMMUNITYMAP <map or server name here> ]");

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------

em_map = em_map or {};

em_map.communitymap_areas = em_map.communitymap_areas or {};

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------

em_map.communityMapReplacesVanilla = em_map.communityMapReplacesVanilla or false; --if this map replaces the entire map set = true;

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------

-- if this server/map has custom areas (e.g. trading post) define them here.
-- non-pvp areas will be added automatically, using saved title and boundary data.
-- example 100 tile square from 1, 1 to 100, 100 in green.
-- em_map.communitymap_areas["Example (PVE)"] = {x1 = 1, y1 = 1, x2 = 100, y2 = 100, r = 1, g = 1, b = 0, a = 0.5};
-- em_map.communitymap_areas["Example (PVP)"] = {x1 = 1, y1 = 1, x2 = 100, y2 = 100, r = 1, g = 1, b = 0, a = 0.5};

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------

-- Custom Areas

-- x1, y1 are top-left corner coordinates (north west corner).
-- x2, y2 are bottom-right corner coordinates (south east corner).

-- Custom Areas must be rectangular or square.
-- Custom Areas must have a unique key/name.

-- Setting the name to spaces (" ") creates overlay without text.
-- Setting alpha (a) to zero (0) creates text without overlay.
-- Setting alpha (a) too high will hide the map underneath. Don't set above 0.9 unless this is desired.

-- em_communitymap.lua must have a unique name or path for compatibility.
-- if multiple em_communitymap.lua are found in the same path in different mods, PZ will only enable one.

---------------------------------------------------------------------------------------------------- do not edit below
---------------------------------------------------------------------------------------------------- V---------------V

local callback_chain_load_community_minimapTile;

if em_map.callback_chain_load_community_minimapTile ~= nil then
	callback_chain_load_community_minimapTile = em_map.callback_chain_load_community_minimapTile;
end

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------

function em_map:callback_chain_load_community_minimapTile(_index)
	self.mapTiles[_index] = getTexture("media/textures/mapTiles/cell_" .. _index .. ".png");
	if not self.mapTiles[_index] and callback_chain_load_community_minimapTile ~= nil then
		callback_chain_load_community_minimapTile(self, _index);
	end;
end

----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------